---
url: /jobs/eigyo
title: "営業ってどんな仕事？未経験から考えるときに｜はじめて転職ガイド"
description: "人と話すのが好き、成果が給料に反映される仕事に興味がある人へ。ノルマのことや向き不向きの確かめ方も。"
source:
  - src/app/jobs/[slug]/page.tsx
  - src/components/TaxonomyHub.tsx
  - src/lib/taxonomy.ts
  - src/components/Eyecatch.tsx
  - content/images/index.json
  - src/components/PageHero.tsx
---

[戻る](/jobs)

パンくず: [ホーム](/) › [職種から探す](/jobs) › 営業

職種・営業

# 営業ってどんな仕事？未経験から考えるときに

人と話すのが好き、成果が給料に反映される仕事に興味がある人へ。ノルマのことや向き不向きの確かめ方も。

人と話す量

[図: 人と話す量: 5段階中5（多い）] 多い

パソコン作業

[図: パソコン作業: 5段階中3（ふつう）] ふつう

数字の目標

[図: 数字の目標: 5段階中5（ほぼある）] ほぼある

[ほかの職種と比べる](/jobs#hojin-eigyo)

[営業](/jobs/eigyo) ・ [事務](/jobs/jimu) ・ [カスタマーサポート](/jobs/customer-support) ・ [ITサポート](/jobs/it-support) ・ [人事・採用](/jobs/jinji) ・ [販売・接客](/jobs/hanbai) ・ [その他の職種](/jobs/sonota)

## まず読むなら、この3本

- ### [不動産営業、歩合ってどうなの？](/articles/fudousan-eigyo)
  不動産営業は、住まいや土地を借りたい・買いたい・売りたい人の相談に乗り、取引をまとめる仕事です。賃貸仲介と売買仲介の違い、宅地建物取引士（宅建士）の役割と試験、歩合がある給与の確認のしかた、接客経験の伝え方を紹介します。
  更新 2026.10.10
- ### [営業事務って、一般事務と何が違う？](/articles/eigyo-jimu-shigoto)
  営業事務は、営業担当の依頼を受けて見積書や受注の入力、取引先からの問い合わせ対応などを行い、営業活動を支える仕事です。一般事務との違い、1日の流れの例、よく使うスキル、未経験で応募する前に求人で確認しておきたいことをまとめました。
  更新 2026.10.09
- ### [接客の経験、ほかの仕事で活かせる？](/articles/sekkyaku-keiken-ikasu)
  接客の仕事には、相手の要望を聞き取る力や、混雑時の段取り、クレーム対応など、ほかの職種でも使える経験が含まれています。経験を分解して、営業・カスタマーサポート・事務などにどうつながるかを整理します。
  更新 2026.10.12

## もう少し調べたいこと 2本

- [営業・カスタマーサポート・ITサポートの違いは？仕事内容と向き不向きを比べる](/articles/eigyo-cs-it-support-chigai)
- [営業が怖い人へ。不安を分けて確認したい仕事内容と面接での質問例](/articles/eigyo-kowai)

[迷ったら、条件整理チェック 13の質問で、比べる職種と確認ポイントを整理](/check)

悩みから探す

- [給料を上げたい](/concerns/kyuryo)
- [土日休みにしたい](/concerns/donichi)
- [オフィスワークに行きたい](/concerns/office)
- [正社員になりたい](/concerns/seishain)
- [未経験の職種に挑戦したい](/concerns/mikeiken-shokushu)
- [今の仕事を辞めたい](/concerns/yametai)
- [面接・書類が不安](/concerns/mensetsu)
- [やりたい仕事が分からない](/concerns/yaritai)

今の状況から探す

- [フリーター](/situations/freeter)
- [派遣社員](/situations/haken)
- [正社員経験が少ない](/situations/seishain-keiken-sukunai)
- [接客・販売の経験](/situations/sekkyaku)
- [第二新卒](/situations/dainishinsotsu)
- [初めての転職](/situations/hajimete)
- [転職回数が多い](/situations/kaisu)
- [PC仕事が未経験](/situations/pc-mikeiken)

仕事選びと応募の準備を相談する

会社選びから面接の練習まで、キャリアアドバイザーに相談しながら準備できます。応募するかどうかは、ご自身で決められます。

[キャリア相談を申し込む](/consultation/apply?placement=article-sidebar__roles-eigyo)

[相談の内容を確認する](/consultation)
