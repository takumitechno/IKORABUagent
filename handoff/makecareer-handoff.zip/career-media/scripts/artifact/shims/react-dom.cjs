module.exports = window.ReactDOM;
