# AGENTS.md — はじめて転職ガイド（career-media）

Codex などのコーディングエージェント向けの作業ガイド。人向けの説明は `README.md`。

## これは何か

- 20〜30代の「はじめての転職・未経験転職」向けオウンドメディアの MVP（Next.js 16 / React 19 / Tailwind CSS 4）。SNSから来た人が短いコピーと絵で選べるUIを優先する。
  記事・ニュース解説・職種比較・条件整理チェックで考えを整理してもらい、人材紹介会社のキャリア相談（面談）へつなぐ。
- **サイトの目的（プロジェクトオーナーの方針、2026-10-10）:** 読者に提携先のキャリア相談（面談）を使ってもらい、自分に合う会社への就職につなげる。
  「はじめて・未経験の転職は、ひとりで悩むより転職のプロ（キャリアアドバイザー／転職エージェント）に相談しながら進めたほうがいい」という方向でサイト全体を作る。
  相談でできること（企業選びの相談・面接の練習・書類の添削・求人の紹介・日程や条件の調整）は `partner.serviceHighlights`、
  記事のカテゴリごとの相談 CTA の文言は `src/lib/cta-copy.ts`、トップの悩み別導線は `ConsultationPreview`、支援見本は `SupportSample`、相談先説明は `ConsultationTrust`。
  ただし成果の保証（必ず内定・年収が上がる）や根拠のない数字・体験談は書かない。応募するかどうかは本人が決める、を添える。
- **提案用・非公開。** 本番環境や公開 URL にデプロイしない（Vercel・Netlify・GitHub Pages なども含む）。
  `partner.brandUsageApproved` を `true` にしない。`SITE_INDEXABLE` を設定しない。
- 画面の既定は中立デモ「はじめて転職ガイド」（提案用デモ。架空の人材紹介会社が運営しているようには見せない）。
  提携候補の実在企業の社名・LP の URL は `src/config/partner.ts`（`makecareer` プロファイル＝商談用の非公開プレビュー）と
  TODO コメントにだけ置く。画面・記事・他のファイルへ直書きしない（`tests/consultation.test.ts` が検出する）。
  LP や企業サイトの文章・画像・ロゴ・実績を写さない。一次情報で確認していない許可番号は画面に出さない。
- **MakeCareer 版（`PARTNER_PROFILE=makecareer`、`npm run demo:makecareer`）は、MakeCareer 帰属の商品として作る。**
  メディア名「MakeCareer転職エージェント（仮）」、相談ボタン「MakeCareerに相談する」、配色は `src/app/globals.css` の
  `html[data-brand="makecareer"]`（仮のネイビー×オレンジ。ブランドガイド受領後に差し替え）。ブランドで変わる文言は `partner.ts` の
  `adviserLabel` / `consultCta` / `proLabel` / `heroBadge` / `theme`。ロゴは許諾があるまで汎用のマーク＋文字。
  ローカル・非公開のまま（claude.ai のアーティファクトや静的書き出しは中立版だけ。スクリプトが実在企業名義を拒否する）。
  商談で手元に渡す1ファイル版だけは、`PARTNER_PROFILE=makecareer SALES_DEMO=1` で起動したサーバーに対して
  `npx tsx scripts/artifact/build-artifact.ts --base <URL> --out <file.html> --private-brand` で作れる
  （商談用プレビューの表示があること・本番の申込ページへのリンクがないことを確かめてから書き出す。公開しない）。
- **本番送客（実際の申込ページへのリンク）を有効にしない。** 有効になるのは `brandUsageApproved: true`・人が書いた
  `liveOutboundApproval`・`PARTNER_LIVE_OUTBOUND=on` の3つがそろったときだけ。エージェントはこのどれも書き換えない。
  相談の申込ボタンは `buildConsultationUrl()` だけで作る（無効の間はサイト内の `/consultation/apply` を指す）。
  確認: `npm run check:outbound -- --base <起動中のURL>`

## まず読むもの

| 知りたいこと | 読む場所 |
|---|---|
| 各ページに実際に表示される内容 | `export/pages/PAGES.md` から各ページの Markdown（書き出し時点のスナップショット。正本は `src/` と `content/`） |
| 読者像・言葉づかい | `docs/PERSONA.md` |
| 記事の書き方・frontmatter・図解 | `.claude/skills/career-article-writer/SKILL.md` |
| 査読の基準（機械チェック C01〜C18） | `.claude/skills/career-article-reviewer/SKILL.md`、`pipeline/src/checks.ts` |
| URL・内部リンクのルール | `.claude/skills/editorial-url-rules/SKILL.md` |

## コマンド

Node.js 20.9 以上。依存は `npm ci`。環境変数なしで動く（記事は `content/` の Markdown から読む）。

| コマンド | 内容 |
|---|---|
| `npm run dev` | 開発サーバー（http://localhost:3000） |
| `npm run build && npm run start` | 本番ビルドで確認（http://localhost:3000） |
| `npm run lint` | TypeScript の型チェック（`tsc --noEmit`） |
| `npm test` | テスト（vitest） |
| `npm run content:check` | 全記事の機械チェック。review / published にエラーがあれば失敗。日付を固定するなら `PIPELINE_TODAY=YYYY-MM-DD` |
| `npm run motifs` | `src/lib/illustrations/motifs.ts` から `src/app/motifs.css` を作り直す |
| `npm run db:verify` | ローカル Postgres で migration・seed・RLS を検証（Postgres が必要） |
| `npm run screenshots` | 起動中のサーバーの主要画面をデスクトップ・スマホで撮影し、横スクロール・はみ出し・コンソールエラーを検出（Playwright の Chromium が必要） |
| `npm run demo` / `npm run demo:makecareer` | 中立デモ（:3000）／商談用プレビュー（:3100）を、商談用ページ（/sales）つきでローカル起動 |
| `npm run check:outbound` | 起動中のサーバーの全ページに、本番の申込ページへのリンクがないことを確認 |
| `npm run sales:docs` | `src/lib/sales/*` と計測の定義から docs/sales/ の資料を作り直す |
| `npm run sns:images` | 投稿案のカルーセルを 1080×1350 の PNG に書き出す（SALES_DEMO のデモが必要） |
| `npm run illustrations` | 人物入りの場面イラスト（Open Peeps＋サイトの色）を `public/images/illustrations/*.svg` に作り直す（今のページでは使っていない。素材として残している） |
| `npm run image:dry-run -- --brief docs/image-briefs/<slug>.md` | 画像生成の確認（API を呼ばない・無料）。保存先と最終 prompt を表示 |
| `npm run image:generate -- --brief docs/image-briefs/<slug>.md` | OpenAI の画像生成 API で1枚作り、`public/images/generated/` と `content/images/meta/` に保存（要 `OPENAI_API_KEY`。状態は draft） |
| `npm run image:status -- <slug> selected` / `image:index` / `image:validate` / `image:prune` | 採用・一覧の作り直し・記録と画像の検査・不採用の削除 |
| `npm run export:static` | 起動中のサーバーの全ページを `export/pages/`（Markdown、リポジトリに置く）と `export/site/`（静的 HTML、git 管理外）に書き出す。対象は既定で http://127.0.0.1:3000（`--base` で変更） |

変更したら、最後に `npm run lint`、`npm test`、`npm run content:check` を通す。画面や記事を変えたら `npm run build && npm run start` のうえで
`npm run screenshots` を通し、`npm run export:static` で `export/pages/` を書き出し直す（Chromium がない環境ではその旨を伝える）。

## ページとソースの対応

| URL | ページ | 主な部品・データ |
|---|---|---|
| `/` | `src/app/page.tsx` | 短い見出しと背景だけ透過した人物写真、`ConsultationPreview`（3つのアイコン入口→支援内容・相談ボタン→架空の具体例）、アイキャッチ付き新着記事3件・ニュース3件と一覧へのリンク、`ConsultationTrust`、`ConditionNotePreview`、代表記事6件と検索。新着は既存リポジトリの公開日順、10分ごとに再検証（静的版は再書き出しが必要）。明暗に対応し、SEO記事本文を保持 |
| `/articles`、`/articles/[slug]` | `src/app/articles/` | `ArticleCards`、`ArticleParts`、`lib/markdown.ts`、`lib/figures.ts`、`content/articles/*.md` |
| `/news`、`/news/[slug]` | `src/app/news/` | `NewsTimeline`、`content/news/*.md` |
| `/categories/[slug]` | `src/app/categories/[slug]/page.tsx` | `content/categories.json` |
| `/jobs`、`/jobs/[slug]` | `src/app/jobs/` | `JobMap`、`LevelMeter`、`TaxonomyHub`、`lib/jobs.ts` |
| `/concerns`、`/situations`（と各 `[slug]`） | `src/app/concerns/`、`src/app/situations/` | `TaxonomyHub`、`lib/taxonomy.ts` |
| `/check` | `src/app/check/page.tsx` | 架空の出力見本は折りたたみ、最初の質問を優先。`ConditionCheck`（クライアント）、`lib/condition-check/`（設問とルール） |
| `/consultation` | `src/app/consultation/page.tsx` | `lib/consultation.ts`（相談ボタンの URL はすべて `buildConsultationUrl`） |
| `/about`、`/editorial-policy`、`/disclosure`、`/privacy`、`/disclaimer` | 各 `page.tsx` | `InfoPage` |
| 全ページ共通 | `src/app/layout.tsx` | `Header`（`ThemeToggle`）、`MobileNav`、`CategoryBar`、`Footer`、`PreviewBanner`（自動相談ポップアップは表示しない）、`MobileStickyCta`、`NavTracker`、`src/app/globals.css` |
| ページ上部 | `src/components/PageHero.tsx` | 記事一覧・カテゴリ・ニュース・職種・チェック・相談・入口ページ・案内ページで共通。キャンバス色・細い区切り・同じ文字階層を使う |
| パンくずと「戻る」 | `src/components/Breadcrumbs.tsx` | `BackButton`（サイト内で移動してきたときは履歴で戻る。直接開いたときはひとつ上の階層へ）。アーティファクト版は `scripts/artifact/runtime.js` がページ内の履歴で処理する |

| `/consultation/apply` | `src/app/consultation/apply/page.tsx` | 本番送客が無効な間の、相談の申込ボタンの行き先（noindex） |
| `/sales/*`（SALES_DEMO=1 のときだけ） | `src/app/sales/` | 商談用ページ（Instagram 投稿案・提案・計測）。データは `src/lib/sales/` |

現在の掲載数: 記事103本（未公開の下書き2本は別）（うち「制度・手続き」カテゴリ `seido` に失業手当・健康保険・年金・住民税・年末調整・試用期間・有休など。面接・書類の実践記事、営業事務・経理・コールセンター・介護・医療事務・施工管理・ドライバーなどの職種記事、求人の条件（賞与・福利厚生・転勤・リモート）や相談先の記事、エージェント・面接練習・企業選びをプロに頼むよさの記事も）、ニュース解説7本。
査読の記録は `content/reviews/<slug>.json`（`npm run pipeline -- review <slug>` が書く）。入口タイルは同じブランド色の丸いアイコンを使い、その入口の記事数をラベル下に出している（`EntryGrid` の `counts`）。

読者導線（3つのガイド）は `src/lib/journeys.ts`（入口ページの「順番に読むなら」と、記事の「ガイドの現在地」に出る）。
計測イベントは `src/lib/measurement/`（ブラウザ内に記録するだけで送信しない）。

データは `src/lib/content/repository.ts` の `ContentRepository` 経由で読む（既定は Markdown、`CONTENT_SOURCE=supabase` で Supabase）。
どちらも status=published で、公開日・査読日・情報確認日・出典がそろった記事だけを返す。

## 画像（生成画像）

- 方針は `docs/ART_DIRECTION.md`、手順は `docs/image-briefs/README.md`。まず画像なしで成り立たせ、必要な場所だけに使う。文字は画像に入れない
- 生成画像は `src/components/GeneratedImage.tsx` で出す（`content/images/index.json` で status が selected のものだけ）。差し込み口は `/sales/sns/*` の表紙 `sns-theme-*-cover` とトップ・共有 `Eyecatch`。トップでは `career-support-team-cutout` の架空人物写真を補助に使い、顔に透明度やグラデーションをかけない。背景の色・曲線と写真を一体にし、短い相談価値・悩みの選択肢・CTAを優先。新着6件の生成イラストはHomeと記事・ニュース一覧で共通。追加記事に専用絵がなければ既存SVGのモチーフとHTMLの短い問いを使い、本文や日付は変えない。共通の色・区切り・ボタン形状を相談・チェック・結果まで揃える。相談ページでは生成人物写真を使わず、公開情報に基づく相談先の説明と架空と明示した支援見本を表示。実在の利用者・相談員の証明には使わない。
- トップは短いコピーと選べる入口を優先。長い比較表・手順・相談説明を重複させない。架空のチャット・予約UIは使わない。
- 生成した画像は draft のまま。実際のページで確認してから `image:status` で selected にする。気に入らなければ brief を直して `--force` で作り直す（前の画像は `.image-history/`）
- API キー（`OPENAI_API_KEY`）は `.env.local` か環境変数にだけ置く。ロゴ・実在の企業やキャラクターは生成しない（`BLOCKED_TERMS`）

## 守ること

- **記事の公開は人間だけ。** エージェントは記事を `status: published` にしない。`reviewed_at` を書き換えない。
  公開は `npm run pipeline -- publish <slug> --approved-by <名前>`（人間が実行）。公開済み記事の本文を変えたら `updated_at` を更新し、再査読が必要。
- 成果を保証する表現（「必ず転職できる」「年収が必ず上がる」など）を書かない（C07）。
  年収や属性で読者をラベリングしない（例: 「年収350万円以下向け」）、業界用語を使わない（C17）。
- 記事本文に生の HTML を書かない（エスケープされる）。図解は ```figure ブロックで書き、図解の数字は本文にあるものだけ（C18）。
- 内部リンクは公開済みのページにだけ張る（C05）。相談先 LP の URL・計測パラメータを記事に書かない。
- 新しい機械チェックを足すときは `pipeline/src/checks.ts`・`tests/checks.test.ts`・reviewer の SKILL.md の表を同時に更新する。
- 画面はスマホ（幅 390px）を基準に作り、横スクロールを出さない。
- 動きは `@media (prefers-reduced-motion: no-preference)` の中だけに書き、動き始めの状態でも文字が読めるようにする。
- 色は必ずトークン（`bg-surface` / `text-ink` / `bg-brand-tint` など）で書く。`bg-white`・`#xxxxxx` を直書きするとダークモードで崩れる。
  白い文字を載せる面は `bg-night`・`bg-brand`・`bg-accent`・`bg-hero`、その押下色は `bg-brand-press` / `bg-accent-press`（ダークでも変わらない）。
  ダークモードは OS 設定に従い、ヘッダー（スマホはメニュー内）の `ThemeToggle` で `html[data-theme]` を上書きする。値は `globals.css` のダークの節。
- イラストは外部素材を使わず `src/lib/illustrations/motifs.ts` に SVG で描く。`src/app/motifs.css` は手で編集せず `npm run motifs` で作る
  （テストが生成漏れを検出する）。外部の画像・フォント・CDN を読み込まない。
- 独自の CSS は `globals.css` の `@layer components` に書く（Tailwind のユーティリティで上書きできるように）。
- `.env*` を読まない・commit しない。フロントで使う Supabase のキーは anon key だけ。
- 記事の日付（published_at・updated_at・reviewed_at・information_checked_at）を、実際より前にさかのぼらせない。今日に変えて新しく見せることもしない。
- 体験談・取材・監修・相談の実績・アクセス数・ランキング・口コミを作らない。架空の給与例は「仮の例」と書く。
- 計測イベントに、氏名・連絡先・自由記述・検索語・条件整理チェックの回答を入れない。登録・面談などの成果イベントをフロントで発火しない。
  本番の解析ツール（GA4・GTM・各種ピクセル）を入れない。
- 商談用ページ（/sales）は読者向けのメディアと分ける。sitemap・ナビに載せない。

## この制作環境の追加ツール

UI設計・改修では、利用可能な `frontend-design` を優先する（このPCの配置は `C:/Users/takum/.agents/skills/frontend-design/SKILL.md`）。既存の制作方針・SEO原稿・上記の安全ルールを優先する。共通の `playwright_local` は `enabled = false` を維持し、関連作業時だけ `python C:/Users/takum/.codex/tools/playwright-local/check_local.py http://127.0.0.1:<port> --project <このチャットの作業フォルダー>` で確認する。実行前に認証なし・本番接続なし・外部通信なしのローカル開発ページであることをソースと起動設定で確かめる。既存プロジェクトの上書き・禁止・安全設定を迂回しない。画像とログを確認してから報告し、PC・スマホで問題があれば修正して再確認する。既存 `scripts/screenshots.mjs` とアプリ内ブラウザも使用可。導入記録は `../../../.codex/WEB_TOOLS.md`。グローバル設定や他プロジェクトは変更しない。
