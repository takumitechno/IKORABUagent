---
slug: news-kyouiku-kunren-kyufu
kind: news
title: 学び直しの支援が拡充｜教育訓練給付の引き上げと教育訓練休暇給付金
summary: 雇用保険の教育訓練給付は、2024年10月から給付率の上限が引き上げられ、2025年10月には教育訓練休暇給付金が新設されました。未経験の職種に挑戦するためにスキルを身につけたい人に関係する制度変更を解説します。
status: published
categories: [news, junbi]
featured: false
recommended: false
published_at: 2026-10-06
updated_at: 2026-10-06
reviewed_at: 2026-10-06
information_checked_at: 2026-10-06
roles: []
concerns: [mikeiken-shokushu]
situations: [pc-mikeiken]
eyecatch: ["転職前に学びたい。", "講座の費用、補助ある？"]
illustration: graduation
related: [ai-shigoto-mikeiken, news-koyou-hoken-kyufu-seigen, eigyo-cs-it-support-chigai]
news:
  announced_by: 厚生労働省
  announced_at: 2025-10-01
  date_type: effective
  what_happened: 令和6年の雇用保険法改正により、2024年10月1日から教育訓練給付金の給付率の上限が引き上げられました（専門実践教育訓練では、受講後に賃金が上昇した場合などの条件を満たすと、受講費用の最大80%）。さらに2025年10月1日からは、雇用保険の被保険者が教育訓練のために休暇を取った場合に、賃金の一定割合を支給する「教育訓練休暇給付金」が設けられました。
  who_is_affected: 雇用保険に加入して働いている人や、一定期間内に離職した人で、資格取得やスキルアップのための講座を受けようとしている人が主な対象です。
  impact_for_career_changers: ITや事務などの職種に挑戦する前に、指定された講座でスキルを身につける場合の費用負担を軽くできる可能性があります。在職中に学んでから転職するという進め方も検討しやすくなりました。
  unknowns:
    - 給付の対象になるのは、厚生労働大臣の指定を受けた講座だけです。受けたい講座が対象かどうかは個別に確認が必要です。
    - 受給には一定期間以上の雇用保険の加入期間などの条件があり、給付率は講座の種類や受講後の状況によって変わります。
    - 講座を修了したことが、そのまま希望する職種への採用につながるとは限りません。
  what_to_check:
    - 受けたい講座が教育訓練給付の指定講座かどうか
    - 自分の雇用保険の加入期間が、支給の条件を満たしているか
    - 受講前に必要な手続き（講座によっては受講開始前の手続きが必要です）
    - 志望する職種で、その資格やスキルが実際にどう評価されるか
sources:
  - title: 雇用保険制度の改正内容について
    publisher: 厚生労働省
    url: https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000160564.html
    accessed_at: 2026-10-06
    used_for: 教育訓練給付の拡充と教育訓練休暇給付金の概要
  - title: 雇用保険法等の一部を改正する法律の概要
    publisher: 厚生労働省
    url: https://www.mhlw.go.jp/content/11600000/001255172.pdf
    accessed_at: 2026-10-06
    used_for: 各改正の施行期日
---

未経験の職種に挑戦するとき、「入社前に少しでもスキルを身につけておきたい」と考える人は多いと思います。今回の制度変更は、そうした学び直しの費用や時間の負担を軽くする方向のものです。

```figure
type: steps
title: 学び直しの支援が変わった時期
items:
  - label: 2024年10月1日から
    text: 教育訓練給付金の給付率の上限を引き上げ（最大80%）
  - label: 2025年10月1日から
    text: 教育訓練休暇給付金が設けられた
```

一方で、注意したいのは「資格を取れば転職できる」とは限らない点です。未経験者を採用する会社の多くは、資格そのものよりも、仕事への理解や学び続ける姿勢を見ています。講座を選ぶ前に、志望する職種で何が求められているかを調べ、必要なら人材紹介会社のキャリアアドバイザーなどに「その資格が実際の求人でどう評価されるか」を確認してから決めると、時間とお金を無駄にしにくくなります。

AIの普及で仕事の中身がどう変わるかについては、[AIで変わる仕事を、未経験転職者はどう見るべきか](/articles/ai-shigoto-mikeiken)でも解説しています。
