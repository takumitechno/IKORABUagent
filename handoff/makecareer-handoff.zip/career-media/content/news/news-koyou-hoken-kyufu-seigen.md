---
slug: news-koyou-hoken-kyufu-seigen
kind: news
title: 自己都合退職の給付制限が原則1か月に｜退職してから転職活動する人が確認したいこと
summary: 2025年4月1日以降に自己都合で退職した場合、雇用保険の基本手当（いわゆる失業手当）の給付制限期間が原則2か月から1か月に短縮されました。退職してから転職活動を考えている人が、何を確認すべきかを整理します。
status: published
categories: [news, junbi]
featured: false
recommended: false
published_at: 2026-10-06
updated_at: 2026-10-06
reviewed_at: 2026-10-06
information_checked_at: 2026-10-06
roles: []
concerns: [yametai]
situations: [hajimete]
eyecatch: ["辞めてから転職活動、", "手当はいつから？"]
related: [agent-mendan-mae, mikeiken-tenshoku-hajimekata, news-kyouiku-kunren-kyufu]
news:
  announced_by: 厚生労働省
  announced_at: 2025-04-01
  date_type: effective
  what_happened: 令和6年の雇用保険法改正により、2025年4月1日以降に正当な理由なく自己都合で退職した人の基本手当の給付制限期間が、原則2か月から1か月に短縮されました。あわせて、離職期間中や離職日前1年以内に一定の教育訓練を受けた場合には、給付制限が解除されるしくみも設けられています。
  who_is_affected: 今の仕事を自己都合で辞めてから転職活動をしようと考えている人が主な対象です。在職中に転職先を決めてから退職する人には、直接の影響はほとんどありません。
  impact_for_career_changers: 退職してから転職活動に集中する場合、収入が途切れる期間の見通しが立てやすくなりました。ただし、手当を受け取るには条件があり、退職すれば誰でもすぐに受け取れるわけではありません。
  unknowns:
    - 自分が基本手当の受給資格を満たしているかどうかは、雇用保険の加入期間などによって変わります。
    - 過去5年以内に自己都合退職による給付制限を繰り返し受けている場合は給付制限期間が3か月になるなど、例外があります。
    - 給付制限の解除の対象になる教育訓練の範囲は、個別に確認が必要です。
  what_to_check:
    - 雇用保険の加入期間（原則として離職日以前2年間に通算12か月以上の被保険者期間が必要です）
    - 退職理由が自己都合として扱われるのか、それ以外なのか
    - 手続きの窓口となるハローワークでの具体的な手続きと必要書類
    - 在職中に活動するか、退職してから活動するかの比較
sources:
  - title: 雇用保険制度の改正内容について
    publisher: 厚生労働省
    url: https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000160564.html
    accessed_at: 2026-10-06
    used_for: 給付制限期間の見直し内容と施行日
  - title: 雇用保険法等の一部を改正する法律の概要
    publisher: 厚生労働省
    url: https://www.mhlw.go.jp/content/11600000/001255172.pdf
    accessed_at: 2026-10-06
    used_for: 改正の全体像と施行期日
---

「仕事を辞めてから、じっくり転職活動をしたい」と考えている人にとって、生活費の見通しは大きな判断材料です。今回の改正で、自己都合退職のあとに基本手当を受け取れるまでの期間は短くなりました。

```figure
type: compare
style: before-after
title: 自己都合退職の給付制限期間
columns:
  - label: これまで
    items:
      - 原則2か月
  - label: 2025年4月1日以降の退職
    items:
      - 原則1か月
      - 一定の教育訓練を受けた場合は解除されるしくみも
```

ただし、この変更は「辞めても大丈夫」という意味ではありません。基本手当を受け取るには雇用保険の加入期間などの条件があり、受け取れる金額や日数も人によって違います。また、在職中に転職活動をすれば、収入を途切れさせずに次の職場を探せるという利点は変わりません。

退職のタイミングに迷っている場合は、まず自分の雇用保険の加入状況を確認し、在職中に活動する場合と退職してから活動する場合のそれぞれで、スケジュールとお金の見通しを書き出してみてください。転職活動全体の進め方は[未経験転職は何から始める？](/articles/mikeiken-tenshoku-hajimekata)で紹介しています。
