---
slug: news-roudou-jouken-meiji
kind: news
title: 求人で明示される労働条件が増えた｜「業務・就業場所の変更の範囲」とは
summary: 2024年4月から、求人の募集時や労働契約を結ぶときに明示される労働条件に「業務の変更の範囲」「就業場所の変更の範囲」などが加わりました。未経験転職で求人を比べるときに、どこを見ればいいかを解説します。
status: published
categories: [news, hatarakikata]
featured: false
recommended: false
published_at: 2026-10-06
updated_at: 2026-10-06
reviewed_at: 2026-10-06
information_checked_at: 2026-10-06
roles: []
concerns: [mikeiken-shokushu]
situations: [hajimete]
eyecatch: ["入社後の仕事や勤務地、", "どこまで変わる？"]
illustration: search
related: [donichi-yasumi-nenshu-hikaku, tenshoku-kaisu-kininaru, freeter-seishain-hajimeni]
news:
  announced_by: 厚生労働省
  announced_at: 2024-04-01
  date_type: effective
  what_happened: 労働基準法施行規則などの改正により、2024年4月1日から、労働契約を結ぶときに「就業場所・業務の変更の範囲」を明示することになりました。有期契約の場合は、更新上限の有無と内容なども明示の対象です。求人の募集時や職業紹介の際に明示される事項にも、業務・就業場所の変更の範囲や、有期契約の更新の基準が加わっています。
  who_is_affected: これから求人に応募する人、内定を受けて労働契約を結ぶ人のすべてが関係します。契約社員など期間の定めがある働き方を検討している人は、更新上限に関する項目も確認の対象になります。
  impact_for_career_changers: 入社直後の仕事内容や勤務地だけでなく、「将来どこまで変わる可能性があるか」を入社前に確認しやすくなりました。未経験で入社して「聞いていた仕事と違う」と感じるリスクを減らす材料として使えます。
  unknowns:
    - 変更の範囲が明示されていても、実際にどのくらいの頻度で異動や担当変更があるかまでは分かりません。
    - 「会社の定める業務」のように広く書かれている場合、具体的に何が含まれるかは求人票だけでは判断しにくいことがあります。
  what_to_check:
    - 求人票や労働条件通知書の「業務の変更の範囲」「就業場所の変更の範囲」の欄
    - 変更の範囲が広い場合、未経験で入社した人が実際にどんな異動・担当変更を経験しているか
    - 契約社員の場合は、更新上限の有無と、正社員登用の実績
sources:
  - title: 2024年4月から労働条件明示のルールが変わります
    publisher: 厚生労働省
    url: https://www.mhlw.go.jp/stf/newpage_32105.html
    accessed_at: 2026-10-06
    used_for: 改正の概要と施行日
  - title: 企業から受ける労働条件明示のルールが変わります（求職者向けリーフレット）
    publisher: 厚生労働省
    url: https://www.mhlw.go.jp/content/001114112.pdf
    accessed_at: 2026-10-06
    used_for: 募集時・職業紹介時に追加された明示事項
---

求人票や労働条件通知書には、これまでも仕事内容や勤務地が書かれていました。今回のルール変更で大きいのは、**「入社直後」だけでなく「将来の変更の範囲」も書かれるようになった**点です。

たとえば、仕事内容の欄に「（雇入れ直後）カスタマーサポート業務　（変更の範囲）会社の定める業務」と書かれている場合、入社後にほかの部署の業務へ変わる可能性があることを意味します。反対に、変更の範囲が「変更なし」や特定の業務に限られていれば、担当が大きく変わる可能性は低いと読み取れます。

```figure
type: compare
title: 仕事内容の欄の読み方（例）
columns:
  - label: 雇入れ直後
    tone: sky
    items:
      - カスタマーサポート業務
  - label: 変更の範囲
    tone: sand
    items:
      - 会社の定める業務
      - 入社後にほかの部署の業務へ変わる可能性がある
```

未経験転職では、仕事内容がイメージと違うことが早期離職のきっかけになりがちです。求人を比べるときは、給与や休日と同じように、この「変更の範囲」の欄も見比べてみてください。年収や休日の比べ方は[「土日休み」と「年収」をどう比較する？](/articles/donichi-yasumi-nenshu-hikaku)で紹介しています。
