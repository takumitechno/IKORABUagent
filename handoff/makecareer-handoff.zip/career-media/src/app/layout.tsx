import type { Metadata, Viewport } from "next";
import { Noto_Sans_JP } from "next/font/google";
import { NavTracker } from "@/components/BackButton";
import { CategoryBar } from "@/components/CategoryBar";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { MeasurementTracker } from "@/components/MeasurementTracker";
import { PreviewBanner } from "@/components/PreviewBanner";
import { SalesMenuButton } from "@/components/sales/SalesMenuButton";
import { consultationMode, partner } from "@/config/partner";
import { site } from "@/config/site";
import { THEME_INIT_SCRIPT } from "@/lib/theme";
import "./globals.css";

// ビルド時にフォントを取得して自己ホストする（閲覧時に Google へリクエストしない）
const notoSansJp = Noto_Sans_JP({
  weight: ["400", "500", "700"],
  display: "swap",
  preload: false,
  variable: "--font-noto-sans-jp",
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.fullName}｜はじめての転職・未経験転職の仕事選びメディア`, template: `%s｜${site.fullName}` },
  description: site.description,
  applicationName: site.fullName,
  icons: { icon: "/favicon.svg" },
  robots: site.indexable ? { index: true, follow: true } : { index: false, follow: false },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: partner.theme === "makecareer" ? "#1e4fb8" : "#0f7b6c" },
    { media: "(prefers-color-scheme: dark)", color: partner.theme === "makecareer" ? "#0b1222" : "#0d1620" },
  ],
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ja" data-brand={partner.theme} className={notoSansJp.variable} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT_SCRIPT }} />
      </head>
      <body className="min-h-screen antialiased">
        <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-surface focus:px-4 focus:py-2">
          本文へスキップ
        </a>
        <PreviewBanner />
        <Header />
        <CategoryBar />
        <main id="main">{children}</main>
        <Footer />
        <MeasurementTracker mode={consultationMode} />
        <NavTracker />
        <SalesMenuButton />
      </body>
    </html>
  );
}
