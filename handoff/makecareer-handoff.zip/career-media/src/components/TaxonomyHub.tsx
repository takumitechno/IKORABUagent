import Link from "next/link";
import { notFound } from "next/navigation";
import { Scale } from "lucide-react";
import { FeatureCard } from "@/components/ArticleCards";
import { ArticleDirectory } from "@/components/ArticleDirectory";
import { PageHero } from "@/components/PageHero";
import { ConsultationCta } from "@/components/ConsultationCta";
import { EntryGrid } from "@/components/EntryGrid";
import { JourneyGuide } from "@/components/Journey";
import { journeyForHub } from "@/lib/journeys";
import { LevelMeter } from "@/components/LevelMeter";
import { getRepository } from "@/lib/content";
import { MIN_HUB_ARTICLES, pickStartArticles } from "@/lib/content-discovery";
import { getJobRole, LEVEL_LABELS } from "@/lib/jobs";
import { pageMetadata } from "@/lib/seo";
import { findTaxonomy, ROLE_TO_COMPARISON, TAXONOMY, TAXONOMY_GROUPS, taxonomyPath, type TaxonomyGroup } from "@/lib/taxonomy";

export function hubStaticParams(group: TaxonomyGroup) {
  return TAXONOMY[group].map((t) => ({ slug: t.slug }));
}

export async function hubMetadata(group: TaxonomyGroup, slug: string) {
  const item = findTaxonomy(group, slug);
  if (!item) return {};
  const articles = await getRepository().listArticles({ tag: { group, slug } });
  return pageMetadata({ title: item.heading, description: item.description, path: taxonomyPath(group, slug), noindex: articles.length < MIN_HUB_ARTICLES });
}

/** 入口（職種 / 悩み / 今の状況）ごとの記事ハブ */
export async function TaxonomyHub({ group, slug }: { group: TaxonomyGroup; slug: string }) {
  const item = findTaxonomy(group, slug);
  if (!item) notFound();
  const g = TAXONOMY_GROUPS[group];
  const repo = getRepository();
  const [categories, articles, all] = await Promise.all([repo.listCategories(), repo.listArticles({ tag: { group, slug } }), repo.listArticles()]);
  const journey = journeyForHub(taxonomyPath(group, slug));
  const comparison = group === "roles" && ROLE_TO_COMPARISON[slug] ? getJobRole(ROLE_TO_COMPARISON[slug]) : undefined;
  const top = pickStartArticles(articles, taxonomyPath(group, slug));
  const rest = articles.filter((a) => !top.some((start) => start.slug === a.slug));
  const otherGroups = (["concerns", "situations", "roles"] as TaxonomyGroup[]).filter((x) => x !== group);

  return (
    <>
      <PageHero
        crumbs={[
          { name: "ホーム", path: "/" },
          { name: g.title, path: group === "roles" ? "/jobs" : g.basePath },
          { name: item.label, path: taxonomyPath(group, slug) },
        ]}
        eyebrow={`${g.title.replace("から探す", "")}・${item.label}`}
        title={item.heading}
        lead={item.description}
        icon={item.icon}
      />
    <div className="mx-auto max-w-6xl px-4 pt-2 sm:px-6">
      <header>
        {comparison && (
          <div className="relative mt-6 flex flex-col gap-4 rounded-xl bg-surface p-4 ring-1 ring-line sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-wrap gap-x-6 gap-y-2">
              <div>
                <p className="text-xs text-muted">人と話す量</p>
                <LevelMeter level={comparison.talkLevel} label={LEVEL_LABELS.talk[comparison.talkLevel]} srLabel="人と話す量" animate />
              </div>
              <div>
                <p className="text-xs text-muted">パソコン作業</p>
                <LevelMeter level={comparison.pcLevel} label={LEVEL_LABELS.pc[comparison.pcLevel]} srLabel="パソコン作業" animate />
              </div>
              <div>
                <p className="text-xs text-muted">数字の目標</p>
                <LevelMeter level={comparison.targetLevel} label={LEVEL_LABELS.target[comparison.targetLevel]} srLabel="数字の目標" animate />
              </div>
            </div>
            <Link href={`/jobs#${comparison.slug}`} className="inline-flex shrink-0 items-center gap-1.5 text-sm font-bold text-brand-strong hover:underline">
              <Scale className="h-4 w-4" aria-hidden="true" />
              ほかの職種と比べる
            </Link>
          </div>
        )}
      </header>

      <nav aria-label={`ほかの${g.label}`} className="mt-5 flex gap-2 overflow-x-auto pb-2">
        {TAXONOMY[group].map((t) => (
          <Link
            key={t.slug}
            href={taxonomyPath(group, t.slug)}
            aria-current={t.slug === slug ? "page" : undefined}
            className={`shrink-0 rounded-full px-3.5 py-1.5 text-[13px] font-medium ring-1 ${t.slug === slug ? "bg-night text-white ring-night" : "bg-surface text-body ring-line hover:text-brand-strong"}`}
          >
            {t.label}
          </Link>
        ))}
      </nav>

      <div className="mt-6 grid gap-10 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0">
          {articles.length === 0 ? (
            <p className="rounded-[var(--radius-card)] bg-surface p-10 text-center text-sm text-muted ring-1 ring-line">このテーマの記事は準備中です。</p>
          ) : (
            <>
              <h2 className="mb-4 text-lg font-bold text-ink">まず読むなら、この{top.length}本</h2>
              <ul className="swipe md-grid reveal" style={{ ["--cols" as string]: 3 }}>
                {top.map((a) => (
                  <li key={a.slug}>
                    <FeatureCard article={a} categories={categories} />
                  </li>
                ))}
              </ul>
              {rest.length > 0 && (
                <section className="mt-8" aria-label="このテーマの関連記事"><h2 className="mb-3 text-base font-bold text-ink">もう少し調べたいこと <span className="text-sm font-normal text-muted">{rest.length}本</span></h2><ArticleDirectory articles={rest} /></section>
              )}
              {journey && <JourneyGuide journey={journey} articles={all} />}
            </>
          )}
        </div>
        <aside className="space-y-6">
          <Link href="/check" className="tap lift flex items-center gap-3 rounded-[var(--radius-card)] bg-brand p-5 text-white hover:bg-brand-press">
            <span className="motif motif-checklist block h-14 w-14 shrink-0 rounded-full bg-white/90" aria-hidden="true" />
            <span>
              <span className="block font-bold">迷ったら、条件整理チェック</span>
              <span className="text-[12.5px] text-white/80">13の質問で、比べる職種と確認ポイントを整理</span>
            </span>
          </Link>
          {otherGroups.map((og) => (
            <section key={og} aria-label={TAXONOMY_GROUPS[og].title} className="rounded-[var(--radius-card)] border border-line bg-surface p-5">
              <p className="text-sm font-bold text-ink">{TAXONOMY_GROUPS[og].title}</p>
              <div className="mt-3">
                <EntryGrid group={og} variant="chip" />
              </div>
            </section>
          ))}
          <ConsultationCta placement="article-sidebar" contentSlug={`${group}-${slug}`} variant="compact" />
        </aside>
      </div>
    </div>
    </>
  );
}

/** 入口の一覧ページ（/concerns, /situations） */
export async function TaxonomyIndex({ group }: { group: TaxonomyGroup }) {
  const g = TAXONOMY_GROUPS[group];
  const all = await getRepository().listArticles();
  const counts = Object.fromEntries(TAXONOMY[group].map((t) => [t.slug, all.filter((a) => a[group].includes(t.slug)).length]));
  return (
    <>
      <PageHero
        crumbs={[{ name: "ホーム", path: "/" }, { name: g.title, path: g.basePath }]}
        eyebrow={`${TAXONOMY[group].length}つの入口`}
        title={g.title}
        lead={group === "concerns" ? "今いちばん気になっていることから、関係のある記事をまとめて読めます。" : "今の働き方や経歴に近いものを選ぶと、同じ状況の人に向けた記事をまとめて読めます。"}
        icon={group === "concerns" ? "messages" : "flag"}
      />
    <div className="mx-auto max-w-6xl px-4 pt-2 sm:px-6">
      <div className="mt-6">
        <EntryGrid group={group} counts={counts} />
      </div>
      <div className="mt-14">
        <ConsultationCta placement="home-band" />
      </div>
    </div>
    </>
  );
}
